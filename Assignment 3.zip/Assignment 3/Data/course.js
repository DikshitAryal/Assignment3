[
    {
        "courseId": 1,
        "courseCode": "DES720",
        "courseDescription": "Relational Database Design and Implementation"
    },
    {
        "courseId": 2,
        "courseCode": "JAV745",
        "courseDescription": "Java Programming"
    },
    {
        "courseId": 3,
        "courseCode": "OPS705",
        "courseDescription": "Introduction to Cloud Computing"
    },
    {
        "courseId": 4,
        "courseCode": "SQL710",
        "courseDescription": "Database Administration and Management"
    },
    {
        "courseId": 5,
        "courseCode": "WEB700",
        "courseDescription": "Web Programming"
    },
    {
        "courseId": 6,
        "courseCode": "CAP805",
        "courseDescription": "Applied Capstone Project"
    },
    {
        "courseId": 7,
        "courseCode": "CJV805",
        "courseDescription": "Database Connectivity Using Java"
    },
    {
        "courseId": 8,
        "courseCode": "DBD800",
        "courseDescription": "Accessing Big Data"
    },
    {
        "courseId": 9,
        "courseCode": "DBW825",
        "courseDescription": "Datawarehousing"
    },
    {
        "courseId": 10,
        "courseCode": "SEC835",
        "courseDescription": "Security in Databases and Web Applications"
    },
    {
        "courseId": 11,
        "courseCode": "WTP100",
        "courseDescription": "Work Term Preparation (Work-Integrated Learning option only)"
    }
]